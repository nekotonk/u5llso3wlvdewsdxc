u5llso3wlvdewsdxc.exe

C++ GDI Malware made for educational purposes only.
Works in Windows XP - 11
This is (not) my last malware, but i'm taking a small break from making malwares for now